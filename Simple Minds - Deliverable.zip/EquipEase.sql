-- SIMPLE MINDS GROUP 
-- SQL Import Compatibile : PHPMyAdmin
SET FOREIGN_KEY_CHECKS = 0; -- Disable foreign key checks to avoid errors during table creation

DROP TABLE IF EXISTS Rental_Extension;
DROP TABLE IF EXISTS Rental;
DROP TABLE IF EXISTS Booking;
DROP TABLE IF EXISTS Maintenance;
DROP TABLE IF EXISTS Equipment_Item;
DROP TABLE IF EXISTS Equipment;
DROP TABLE IF EXISTS Category;
DROP TABLE IF EXISTS Customer;
DROP TABLE IF EXISTS Service_Company;
DROP TABLE IF EXISTS Staff;
DROP TABLE IF EXISTS Branch;


-- 1. Branch
CREATE TABLE Branch (
    branch_id INT PRIMARY KEY, 
    branch_name VARCHAR (50) NOT NULL, 
    branch_address VARCHAR(150) NOT NULL, 
    city VARCHAR (50) NOT NULL, 
    region VARCHAR (50) NOT NULL,
    manager_staff_id INT /* Manager of this branch */

    /* Change : Removed the Branch -> Staff foreign key because Staff is created later. */
); 

-- 2. Staff 
CREATE TABLE Staff (
    staff_id INT PRIMARY KEY, 
    fname VARCHAR (150) NOT NULL, 
    lname VARCHAR (150) NOT NULL, 
    branch_id INT NOT NULL, -- FK FOR BRANCH
    phone_no VARCHAR (50) NOT NULL, 
    staff_email VARCHAR (150) NOT NULL,
    staff_role ENUM('Staff', 'Manager') NOT NULL DEFAULT 'Staff', -- Staff or Manager
    CONSTRAINT fk_staff_branch FOREIGN KEY (branch_id) REFERENCES Branch(branch_id)
);

-- 3. Category 
CREATE TABLE Category (
    category_id INT PRIMARY KEY,
    category_name VARCHAR (150) NOT NULL,
    category_description VARCHAR (250) NOT NULL
); 

-- 4. Equipment 
CREATE TABLE Equipment (
    equipment_id INT PRIMARY KEY,
    equipment_name VARCHAR (150) NOT NULL,
    equipment_description TEXT,
    equipment_specs TEXT,
    safety_notes TEXT,
    recommended_safety_equipment TEXT,
    category_id INT NOT NULL, -- FK FOR CATEGORY
    CONSTRAINT fk_equipment_category FOREIGN KEY (category_id) REFERENCES Category(category_id)

);

-- 5. Equipment Item 
CREATE TABLE Equipment_Item(
    item_id INT PRIMARY KEY, 
    serial_number VARCHAR (150) NOT NULL UNIQUE,
    item_conditions VARCHAR(250) DEFAULT 'Good', -- Default is set good, user can tell the condition without choices 
    purchase_date DATE NOT NULL,
    item_status ENUM ('Available', 'Rented', 'Maintenance', 'Retired') DEFAULT 'Available', -- With choices to make sure it consistent 
    equipment_id INT NOT NULL, -- FK FOR EQUIPMENT
    branch_id INT NOT NULL, -- FK FOR BRANCH

    CONSTRAINT fk_item_equipment FOREIGN KEY (equipment_id) REFERENCES Equipment(equipment_id),
    CONSTRAINT fk_item_branch FOREIGN KEY (branch_id) REFERENCES Branch(branch_id)
);

-- 6 Service Company
CREATE TABLE Service_Company(
    company_id INT PRIMARY KEY,
    company_name VARCHAR(150) NOT NULL,
    contact_person_name VARCHAR(150) NOT NULL,
    phone VARCHAR(50) NOT NULL,
    email VARCHAR(150) NOT NULL
);

-- 7. Maintenance 
CREATE TABLE Maintenance (
    maintenance_id INT PRIMARY KEY,
    equipment_id INT NOT NULL, -- FK FOR EQUIPMENT
    staff_id INT NOT NULL, -- FK FOR STAFF
    company_id INT NOT NULL, -- FK FOR SERVICE COMPANY
    maintenance_date DATE NOT NULL,
    type ENUM('Monthly', 'Bi-annual(6 months)', 'Annual(1 Year)') NOT NULL DEFAULT 'Monthly',
    additional_notes TEXT,

    CONSTRAINT fk_maintenance_equipment FOREIGN KEY (equipment_id) REFERENCES Equipment(equipment_id),
    CONSTRAINT fk_maintenance_staff FOREIGN KEY (staff_id) REFERENCES Staff(staff_id),
    CONSTRAINT fk_maintenance_company FOREIGN KEY (company_id) REFERENCES Service_Company(company_id)
);

-- 8. Customer
CREATE TABLE Customer (
    customer_id INT PRIMARY KEY,
    fname VARCHAR(150) NOT NULL,
    lname VARCHAR(150) NOT NULL,
    phone VARCHAR(50) NOT NULL,
    email VARCHAR(150) NOT NULL,
    customer_address VARCHAR(150) NOT NULL,
    id_type ENUM('Driver License', 'Passport', 'KiwiAccess', 'Firearms ID', 'Other') NOT NULL, -- Security protocol to rent equipment, to prevent fraud and duplication of customers. 
    id_number VARCHAR(150) NOT NULL UNIQUE -- Has to be unique to avoid fraud and duplication of customers
);

-- 9. Booking 
CREATE TABLE Booking (
    booking_id INT PRIMARY KEY,
    booking_date DATETIME NOT NULL,
    start_date DATETIME NOT NULL,
    end_date DATETIME NOT NULL,
    status ENUM('Pending', 'Confirmed', 'Cancelled', 'Completed') NOT NULL DEFAULT 'Pending',
    equipment_id INT NOT NULL, -- FK FOR EQUIPMENT what equipment is being booked
    customer_id INT NOT NULL, -- FK FOR CUSTOMER what customer is booking the equipment

    CONSTRAINT fk_booking_equipment FOREIGN KEY (equipment_id) REFERENCES Equipment(equipment_id),
    CONSTRAINT fk_booking_customer FOREIGN KEY (customer_id) REFERENCES Customer(customer_id)
);

-- 10. Rental
CREATE TABLE Rental (
    rental_id INT PRIMARY KEY,
    start_date DATETIME NOT NULL,
    end_date DATETIME NOT NULL,
    status ENUM('Pending', 'Confirmed', 'Cancelled', 'Completed') NOT NULL DEFAULT 'Pending',
    pick_branch_id INT NOT NULL, -- FK FOR BRANCH where the customer will pick up the equipment
    return_branch_id INT NOT NULL, -- FK FOR BRANCH where the customer will return the equipment
    actual_return_date DATETIME, -- The actual date/time the customer returned the equipment
    booking_id INT NOT NULL, -- FK FOR BOOKING what booking

    CONSTRAINT fk_rental_pick_branch FOREIGN KEY (pick_branch_id) REFERENCES Branch(branch_id),
    CONSTRAINT fk_rental_return_branch FOREIGN KEY (return_branch_id) REFERENCES Branch(branch_id),
    CONSTRAINT fk_rental_booking FOREIGN KEY (booking_id) REFERENCES Booking(booking_id)
);

-- 11. Rental_Extension
CREATE TABLE Rental_Extension (
    extension_id INT PRIMARY KEY,
    new_end_date DATETIME NOT NULL,
    request_date DATETIME NOT NULL,
    status ENUM('Pending', 'Approved', 'Rejected') NOT NULL DEFAULT 'Pending',
    additional_cost DECIMAL(10, 2) NOT NULL DEFAULT 0.00,
    rental_id INT NOT NULL, -- FK FOR RENTAL

    CONSTRAINT fk_rental_extension FOREIGN KEY (rental_id) REFERENCES Rental(rental_id)
); 

  /* Change : Added the Branch -> Staff foreign key after creating the Staff table. */

ALTER TABLE Branch ADD CONSTRAINT fk_branch_staff FOREIGN KEY (manager_staff_id) REFERENCES Staff(staff_id);

SET FOREIGN_KEY_CHECKS = 1;



/* 1.Branch */
INSERT INTO Branch (branch_id, branch_name, branch_address, city, region, manager_staff_id)
VALUES
(1, 'Hamilton Central', '10 Victoria Street', 'Hamilton', 'Waikato', NULL),
(2, 'Hamilton East', '25 Grey Street', 'Hamilton', 'Waikato', NULL),
(3, 'Te Rapa', '40 Te Rapa Road', 'Hamilton', 'Waikato', NULL),
(4, 'Frankton', '15 Commerce Street', 'Hamilton', 'Waikato', NULL);
 
/* 2. Staff */
INSERT INTO Staff(staff_id, fname, lname, branch_id, phone_no, staff_email, staff_role)
VALUES
(1, 'John', 'Smith', 1, '0211234567', 'john.smith@simpleminds.co.nz', 'Manager'),
(2, 'Emma', 'Davis', 2, '0227654321', 'emma.davis@simpleminds.co.nz', 'Manager'),
(3, 'Liam', 'Wilson', 3, '0223456789', 'liam.wilson@simpleminds.co.nz', 'Manager'),
(4, 'Sophie', 'Taylor', 4, '0219876543', 'sophie.taylor@simpleminds.co.nz', 'Manager'),
(5, 'Noah', 'Anderson', 1, '0225551234', 'noah.anderson@simpleminds.co.nz', 'Staff'),
(6, 'Olivia', 'Martin', 2, '0214445678', 'olivia.martin@simpleminds.co.nz', 'Staff');
 
/* Assign managers back to their branches now that Staff rows exist */
UPDATE Branch SET manager_staff_id = 1 WHERE branch_id = 1;
UPDATE Branch SET manager_staff_id = 2 WHERE branch_id = 2;
UPDATE Branch SET manager_staff_id = 3 WHERE branch_id = 3;
UPDATE Branch SET manager_staff_id = 4 WHERE branch_id = 4;
 
/* 3. Category */
INSERT INTO Category (category_id, category_name, category_description)
VALUES
(1, 'Power Tools', 'Electric and battery powered hand tools'),
(2, 'Excavation Equipment', 'Equipment used for digging and earthmoving'),
(3, 'Concrete Equipment', 'Equipment used for concrete work'),
(4, 'Garden Equipment', 'Equipment used for gardening and landscaping');
 
/* 4. Equipment */
INSERT INTO Equipment (equipment_id, equipment_name, equipment_description, equipment_specs, safety_notes, recommended_safety_equipment, category_id)
VALUES
(1, 'Angle Grinder', 'Handheld cutting and grinding tool', '4.5 inch disc, 850W', 'Wear eye protection at all times', 'Safety glasses, gloves', 1),
(2, 'Mini Excavator', 'Compact excavator for tight job sites', '1.7 tonne, diesel engine', 'Keep clear of swing radius', 'Hard hat, hi-vis vest, steel-cap boots', 2),
(3, 'Concrete Mixer', 'Portable drum mixer for small pours', '120L drum, electric motor', 'Do not place hands near rotating drum', 'Gloves, dust mask', 3),
(4, 'Lawn Mower','Petrol powered lawn mower','4 stroke petrol engine','Keep hands and feet away from blades','Safety shoes and hearing protection', 4);
 
/* 5. Equipment_Item */
INSERT INTO Equipment_Item (item_id, serial_number, item_conditions, purchase_date, item_status, equipment_id, branch_id)
VALUES
(1, 'SN-0001', 'Good', '2024-01-15', 'Available', 1, 1),
(2, 'SN-0002', 'Good', '2023-11-02', 'Rented', 2, 2),
(3, 'SN-0003', 'Fair', '2022-06-20', 'Maintenance', 3, 3),
(4, 'SN-0004', 'Good', '2024-03-10', 'Available', 4, 4);
 
/* 6. Service_Company */
INSERT INTO Service_Company (company_id, company_name, contact_person_name, phone, email)
VALUES
(1, 'ToolFix Ltd', 'Sarah Lee', '0299887766', 'sarah@toolfix.co.nz'),
(2, 'Heavy Machinery Care', 'David Chen', '0298765432', 'david@hmcare.co.nz'),
(3, 'ProService NZ', 'Grace Kim', '0291112222', 'grace@proservice.co.nz'),
(4, 'Waikato Equipment Repairs', 'James Brown', '0274567890', 'james@waikatorepairs.co.nz');
 
/* 7. Maintenance */
INSERT INTO Maintenance (maintenance_id, equipment_id, staff_id, company_id, maintenance_date, type)
VALUES
(1, 1, 1, 1, '2024-06-01', 'Monthly'),
(2, 2, 2, 2, '2024-05-15', 'Bi-annual(6 months)'),
(3, 3, 3, 3, '2024-04-10', 'Annual(1 Year)'),
(4, 4, 4, 4, '2024-07-01', 'Monthly');
 
/* 8. Customer */
INSERT INTO Customer (customer_id, fname, lname, phone, email, customer_address, id_type, id_number)
VALUES
(1, 'Mike', 'Brown', '0223334444', 'mike.brown@email.com', '45 Elm St, Auckland', 'Driver License', 'DL123456'),
(2, 'Olivia', 'Clark', '0225556666', 'olivia.clark@email.com', '12 Oak Ave, Wellington', 'Passport', 'PP987654'),
(3, 'Ethan', 'Walker', '0227778888', 'ethan.walker@email.com', '9 Rimu Rd, Christchurch', 'KiwiAccess', 'KA456789'),
(4, 'Emily', 'Jones', '0216667788','emily.jones@email.com','28 River Road, Hamilton','Driver License', 'DL654321');
 
/* 9. Booking */
INSERT INTO Booking (booking_id, booking_date, start_date, end_date,status, equipment_id, customer_id)
VALUES
(1,'2026-09-01 10:00:00','2026-09-10 09:00:00','2026-09-10 15:00:00','Confirmed', 1, 1),
(2,'2026-09-02 11:30:00','2026-09-12 08:00:00','2026-09-14 17:00:00','Confirmed', 2, 2),
(3,'2026-09-03 14:00:00','2026-09-15 09:00:00','2026-09-16 16:00:00','Confirmed', 3, 3),
(4,'2026-09-04 09:30:00','2026-09-18 10:00:00','2026-09-18 18:00:00','Confirmed', 4, 4);
 
/* 10. Rental */
INSERT INTO Rental (rental_id, start_date, end_date, status, pick_branch_id, return_branch_id, actual_return_date, booking_id)
VALUES
(1,'2026-09-10 09:00:00','2026-09-10 15:00:00','Completed',1, 1,'2026-09-10 14:30:00', 1),
(2,'2026-09-12 08:00:00','2026-09-14 17:00:00','Confirmed',2, 3,NULL, 2),
(3,'2026-09-15 09:00:00','2026-09-16 16:00:00','Confirmed',3, 3,NULL, 3),
(4,'2026-09-18 10:00:00','2026-09-18 18:00:00','Confirmed',4, 1,NULL, 4);
 
/* 11. Rental_Extension */
INSERT INTO Rental_Extension (extension_id, new_end_date, request_date, status, additional_cost, rental_id)
VALUES
(1, '2026-09-10 18:00:00', '2026-09-10 12:00:00', 'Approved', 15.00, 1),
(2, '2026-09-15 17:00:00', '2026-09-13 10:00:00', 'Approved', 30.00, 2),
(3, '2026-09-17 16:00:00', '2026-09-15 14:00:00', 'Pending', 20.00, 3),
(4, '2026-09-19 12:00:00', '2026-09-18 14:00:00', 'Rejected', 0.00, 4);