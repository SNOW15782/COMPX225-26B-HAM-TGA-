<?php
include 'db.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Equipment</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
    <h1>Add Equipment</h1>
    <h2>Staff Portal [MyDashboard]</h2>
    <p>copyright &copy; 2026 EquipEase Rentals. All rights reserved.</p>

    <nav>
        <a href="index.php" class="home-link">Home</a> 
        <a href="add.php" class="home-link">Add Equipment</a> 
        <a href="rentals.php" class="home-link">View Rentals</a>
    </nav>
    

    <?php

    //a. Query the database to insert a new row to the equipment table, based on the 
    //information that was given through the POST request. Display the 
    //information for the new equipment.

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $equipment_id = $_POST['equipment_id'] ?? '';
    $available = $_POST['available'] ?? '';
    $purchase_date = $_POST['purchase_date'] ?? '';
    $branch_name = $_POST['branch_name'] ?? '';
    $type_name = $_POST['type_name'] ?? '';

    $sql = "INSERT INTO equipment (equipment_id, available, purchase_date, branch_name, type_name) VALUES (?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    
    $stmt->bind_param("iisss", $equipment_id, $available, $purchase_date, $branch_name, $type_name);
    $stmt->execute();

    if ($stmt->affected_rows > 0) {

        //Display alert message for successful addition of new equipment
        echo"<script>alert('New equipment added successfully!');</script>";
        
        echo "<p>New equipment added successfully:</p>";
        echo "<ul>";
        echo "<li>Equipment ID: " . htmlspecialchars($equipment_id) . "</li>";
        echo "<li>Available: " . htmlspecialchars($available == 1 ? 'Yes' : 'No') . "</li>";
        echo "<li>Purchase Date: " . htmlspecialchars($purchase_date) . "</li>";
        echo "<li>Branch Name: " . htmlspecialchars($branch_name) . "</li>";
        echo "<li>Type Name: " . htmlspecialchars($type_name) . "</li>";
        echo "</ul>";
    } else {
        echo "<p>Error adding new equipment: " . $stmt->error . "</p>";
        echo "<p>Please ensure that the Equipment ID is unique and try again.</p>";
    }

    $stmt->close();
}

// Query the database for a list of all branches and types, to prevent errors when user type
 $branch_result = $conn->query("SELECT DISTINCT branch_name FROM equipment");
 $type_result = $conn->query("SELECT DISTINCT type_name FROM equipment");
?>

<!--// Part for the form --> 
<form action="add.php" method="POST">
    <label for="equipment_id">Equipment ID:</label>
    <input type="number" id="equipment_id" name="equipment_id" required><br>

    <label for="available">Available:</label>
    <select id="available" name="available" required>
        <option value="1">Yes</option>
        <option value="0">No</option>
    </select><br>

    <label for="purchase_date">Purchase Date:</label>
    <input type="date" id="purchase_date" name="purchase_date" required><br>

    <label for="branch_name">Branch Name:</label>
    <select id="branch_name" name="branch_name" required>

         <!-- Put options to make users select from a list -->
        <option value=""> Select a Branch </option>
        
        <!-- Added options to prevent errors when user types -->

        <?php
        if ($branch_result && $branch_result->num_rows > 0) {
            while ($row = $branch_result->fetch_assoc()) {
                echo "<option value='" . htmlspecialchars($row['branch_name']) . "'>" . htmlspecialchars($row['branch_name']) . "</option>";
            }
        }
        ?>
    </select><br>

    <label for="type_name">Type Name:</label>
    <select id="type_name" name="type_name" required>

        <!-- Put options to make users select from a list -->
        <option value=""> Select a Type </option>

         <!-- Added options to prevent errors when user types -->
          
        <?php
        if ($type_result && $type_result->num_rows > 0) {
            while ($row = $type_result->fetch_assoc()) {
                echo "<option value='" . htmlspecialchars($row['type_name']) . "'>" . htmlspecialchars($row['type_name']) . "</option>";
            }
        }
        ?>
    </select><br>

    <input type="submit" value="Add Equipment">
</form>
<br>

<!--// b. Provide a link for the staff member to return to the index page. -->
<a href="index.php" class="home-link">Return to Index Page</a>
</div>
</body>
</html>
