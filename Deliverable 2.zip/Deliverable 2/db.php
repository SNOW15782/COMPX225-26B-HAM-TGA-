<?php

// Database connection parameters (not tested yet)
$host = "learn-mysql.cms.waikato.ac.nz";
$username = "ms2888";
$password = "my657803sql";
$dbname = "ms2888";

//Connection 
$conn = new mysqli($host, $username, $password, $dbname);

//Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>