<?php
include 'db.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Rentals</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
<h1>Rental Page</h1>
<h2>Staff Portal [MyDashboard]</h2>
<p>copyright &copy; 2026 EquipEase Rentals. All rights reserved.</p>

<nav style="margin-bottom: 20px;">
    <a href="index.php" class="home-link">Home</a> 
    <a href="add.php" class="home-link">Add Equipment</a> 
    <a href="rentals.php" class="home-link">View Rentals</a>
</nav>

<!-- Simple Form to search user email address -->
<form action="rentals.php" method="GET">
    <label for="customer_email">Customer Email:</label>
    <input type="email" id="customer_email" name="customer_email" required>

    <!-- Add validation to the email input to ensure it's a valid email address -->
     
    <input type="email" id="customer_email" name="customer_email" required
           oninvalid="this.setCustomValidity('Please enter a valid email address')"
           oninput="this.setCustomValidity('')">
    <button type="submit">Search Rentals</button>
</form>

<?php
//a. Query the database for a list of all rentals for the customer email address -->

$customer_email = $_GET['customer_email'] ?? '';

//Query the database for rentals associated with the provided customer email
if (!empty($customer_email)) {

$sql = "SELECT rental_id, start_time, hire_from FROM rental WHERE customer_email = ?";

$stmt = $conn->prepare($sql);

$stmt->bind_param("s", $customer_email);

$stmt->execute();

$result = $stmt->get_result();

//Display the result in a table
echo "<table>";
echo "<tr><th>Rental ID</th><th>Start Time</th><th>Hire From</th></tr>";

if ($result && $result->num_rows > 0) {

while ($row = $result->fetch_assoc()) {
    echo "<tr>";
    echo "<td>" . htmlspecialchars($row['rental_id']) . "</td>";
    echo "<td>" . htmlspecialchars($row['start_time']) . "</td>";
    echo "<td>" . htmlspecialchars($row['hire_from']) . "</td>";
    echo "</tr>";
}

} else {
    echo "<tr><td colspan='3'>No rentals found for this customer email.</td></tr>";
}

echo "</table>";

$stmt->close();

} else {
    echo "<p>Please provide a customer email address to view rentals.</p>";
}
$conn->close();
?>

<br>
<!--// b. Provide a link for the staff member to return to the index page. -->
<a href="index.php" class ="home-link">Return to Index Page</a>
    </div>
</body>
</html>
