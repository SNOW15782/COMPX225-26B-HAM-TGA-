<?php
include 'db.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EquipEase Rentals Staff [MyDashboard]</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<!-- //a. Display the company name and instructions telling the EquipEase Rentals staff members how to use this webpage.-->
<div class ="container">
<h1>EquipEase Rentals</h1>
<!--MyDashboard is the name of EquipEase Rentals-->
<h2>Staff Portal [MyDashboard]</h2>

<p>Welcome to the EquipEase Rentals MyDashboard. Here you can view all available equipment, manage rentals, and add new equipment to the inventory.</p>
<p>copyright &copy; 2026 EquipEase Rentals. All rights reserved.</p>

<nav style="margin-bottom: 20px;">
    <a href="index.php" class="home-link">Home</a> 
    <a href="add.php" class="home-link">Add Equipment</a>
    <a href="rentals.php" class="home-link">View Rentals</a>
    <a href="statistics.php" class="home-link">View Statistics</a>
</nav>

<!-- //b. Query the database for a list of all equipment, then display them in a table. -->
<h2>Available Equipment</h2>

<?php 

$sql = "SELECT equipment_id, available, purchase_date, branch_name, type_name FROM equipment";
$result = $conn->query($sql);

//Display the result in a table 
echo "<table>";
echo "<tr><th>Equipment ID</th><th>Available</th><th>Purchase Date</th><th>Branch Name</th><th>Type Name</th></tr>";

if ($result && $result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        echo "<tr>".
        "<td>" . $row["equipment_id"]. "</td>".
        "<td>" . $row["available"]. "</td>".
        "<td>" . $row["purchase_date"]. "</td>".
        "<td>" . $row["branch_name"]. "</td>".
        "<td>" . $row["type_name"]. "</td></tr>";
    }

} else {
    echo "<tr><td colspan='5'>No equipment found in the database</td></tr>";
}
echo "</table>";
?>

<!-- //c. Have a form that allows the staff member to input a customer email address, 
then sends that email in a GET request to rentals.php. -->

<h2>View Customer Rentals</h2>

<form action="rentals.php" method="get">
    <label for="customer_email">Enter Customer Email:</label>
    <input type="email" id="customer_email" name="customer_email" required>
    <input type="submit" value="View Rentals">
</form>

<!-- //d. Have a form that allows the staff member to input all properties for a new 
equipment, then sends that information in a POST request to add.php. -->

<h2>Add New Equipment</h2>

<form action="add.php" method="post">
    <label for="equipment_id">Equipment ID:</label>
    <input type="text" id="equipment_id" name="equipment_id" required><br><br>

    <label for="available">Available (1 for Yes, 0 for No):</label>
    <select id="available" name="available" required>
        <option value="1">Yes</option>
        <option value="0">No</option>
    </select><br><br>

    <label for="purchase_date">Purchase Date (YYYY-MM-DD):</label>
    <input type="date" id="purchase_date" name="purchase_date" required><br><br>

    <label for="branch_name">Branch Name:</label>
    <input type="text" id="branch_name" name="branch_name" required><br><br>

    <label for="type_name">Type Name:</label>
    <input type="text" id="type_name" name="type_name" required><br><br>

    <input type="submit" value="Add Equipment">
</form>

    </div>
</body>
</html>

