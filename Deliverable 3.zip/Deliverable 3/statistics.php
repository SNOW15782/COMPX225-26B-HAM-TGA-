<?php
include 'db.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EquipEase Rentals Staff [MyDashboard]</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<!-- //a. Display the company name and instructions telling the EquipEase Rentals staff members how to use this webpage.-->
<div class ="container">
<h1>EquipEase Rentals</h1>
<!--MyDashboard is the name of EquipEase Rentals-->
<h2>Staff Portal [MyDashboard]</h2>

<p>Welcome to the EquipEase Rentals MyDashboard. Here you can view all available equipment, manage rentals, and add new equipment to the inventory.</p>
<p>copyright &copy; 2026 EquipEase Rentals. All rights reserved.</p>

<nav style="margin-bottom: 20px;">
    <a href="index.php" class="home-link">Home</a> 
    <a href="add.php" class="home-link">Add Equipment</a>
    <a href="rentals.php" class="home-link">View Rentals</a>
    <a href="statistics.php" class="home-link">View Statistics</a>
</nav>

<!-- The top 10 most rented equipment types. -->
<h2>Top 10 Most Most Rented Equipment</h2>
<?php
$sql_top10 = "SELECT et.type_name, COUNT(re.equipment_id) AS rental_count
FROM equipment_type et
JOIN equipment e ON et.type_name = e.type_name
JOIN rent_equipment re ON e.equipment_id = re.equipment_id
GROUP BY et.type_name
ORDER BY rental_count DESC
LIMIT 10";

$result_top10 = $conn->query($sql_top10);

echo "<table>";
echo "<tr><th>Equipment Type</th><th>Rental Count</th></tr>";

if ($result_top10 && $result_top10->num_rows > 0) {
    while($row = $result_top10->fetch_assoc()) {
        echo "<tr>".
        "<td>" . htmlspecialchars($row["type_name"]) . "</td>".
        "<td>" . htmlspecialchars($row["rental_count"]) . "</td></tr>";
    }
} else {
    echo "<tr><td colspan='2'>No rental data found in the database</td></tr>";
}
echo "</table>";
?>

<!-- b. Equipment Type Generating Most Revenue -->
<h2>Equipment Type Generating Most Revenue</h2>
<?php

$sql_revenue = "SELECT et.type_name, 
SUM(TIMESTAMPDIFF(HOUR, r.start_time, re.return_time) * et.rate_per_hour) AS total_revenue
FROM equipment_type et
JOIN equipment e ON et.type_name = e.type_name
JOIN rent_equipment re ON e.equipment_id = re.equipment_id
JOIN rental r ON re.rental_id = r.rental_id
WHERE re.return_time IS NOT NULL
GROUP BY et.type_name
ORDER BY total_revenue DESC
LIMIT 1";

$result_revenue = $conn->query($sql_revenue);

echo "<table>";
echo "<tr><th>Equipment Type</th><th>Total Revenue</th></tr>";

if ($result_revenue && $result_revenue->num_rows > 0) {
    while($row = $result_revenue->fetch_assoc()) {
        echo "<tr>".
        "<td>" . htmlspecialchars($row["type_name"]) . "</td>".
        "<td>$" . number_format($row["total_revenue"], 2). "</td></tr>";
    }
} else {
    echo "<tr><td colspan='2'>No revenue data found in the database</td></tr>";
}
echo "</table>";
?>

<!-- c. Top 3 Customers with Most Rentals -->
<h2>Top 3 Customers with Most Rentals</h2>
<?php

$sql_customers = "SELECT c.f_name, c.s_name, c.email, COUNT(r.rental_id) AS rental_count
FROM customer c
JOIN rental r ON c.email = r.customer_email
GROUP BY c.email, c.f_name, c.s_name
ORDER BY rental_count DESC
LIMIT 3";

$result_customers = $conn->query($sql_customers);

echo "<table>";
echo "<tr><th>Customer Name</th><th>Email</th><th>Rental Count</th></tr>";

if ($result_customers && $result_customers->num_rows > 0) {
    while($row = $result_customers->fetch_assoc()) {
        echo "<tr>".
        "<td>" . htmlspecialchars($row["f_name"] . " " . $row["s_name"]) . "</td>".
        "<td>" . htmlspecialchars($row["email"]) . "</td>".
        "<td>" . htmlspecialchars($row["rental_count"]) . "</td></tr>";
    }
} else {
    echo "<tr><td colspan='3'>No customer data found in the database</td></tr>";
}
echo "</table>";
?>

<!-- d. Branch Rentals During August 2026 -->
<h2>Branch Rentals During August 2026</h2>
<?php
$sql_branch_rentals = "SELECT hire_from AS branch_name, COUNT(*) AS rental_count
FROM rental
WHERE start_time >= '2026-08-01 00:00:00'
AND start_time < '2026-09-01 00:00:00'
GROUP BY hire_from";

$result_branch_rentals = $conn->query($sql_branch_rentals);

echo "<table>";
echo "<tr><th>Branch Name</th><th>Rental Count</th></tr>";

if ($result_branch_rentals && $result_branch_rentals->num_rows > 0) {
    while($row = $result_branch_rentals->fetch_assoc()) {
        echo "<tr>".
        "<td>" . htmlspecialchars($row["branch_name"]) . "</td>".
        "<td>" . htmlspecialchars($row["rental_count"]) . "</td></tr>";
    }
} else {
    echo "<tr><td colspan='2'>No branch rental data found for August 2026</td></tr>";
}
echo "</table>";
?>

<br> 
<a href="index.php" class="home-link">Back to Home</a>
</div>
</body>
</html>
